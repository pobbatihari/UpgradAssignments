# Import routines

import numpy as np
import math
import random
import math

# Defining hyperparameters
m = 5 # number of cities, ranges from 1 ..... m
t = 24 # number of hours, ranges from 0 .... t-1
d = 7  # number of days, ranges from 0 ... d-1
C = 5 # Per hour fuel and other costs
R = 9 # per hour revenue from a passenger


class CabDriver():

    def __init__(self):
        """initialise your state and define your action space and state space"""
        #Action is a list of [pickup,drop].
        self.action_space = [(x,y) for x in range(m) for y in range(m) if x!=y]
        self.action_space.append((0,0)) #noride
        
        #State is a list of [location,time,day]
        self.state_space = [[x,y,z] for x in range(m) for y in range(t) for z in range(d)]

        #Random initial state
        self.state_init = random.choice(self.state_space)
        # Start the first round
        self.reset()


    ## Encoding state (or state-action) for NN input

    def state_encod_arch1(self, state):
        """convert the state into a vector so that it can be fed to the NN. This method converts a given state into a vector format. Hint: The vector is of size m + t + d."""
        if not state:
            return
        
        #Create a vector of loc+time+day
        state_encod=np.zeros(m+t+d,dtype='int')
        #Set the respective location to 1
        state_encod[state[0] - 1] = 1
        # encode hour of the day
        state_encod[m + state[1]] = 1       
        # encode day of the week
        state_encod[m + t + state[2]] = 1
        return state_encod

        
    # Use this function if you are using architecture-2
    # def state_encod_arch2(self, state, action):
    #     """convert the (state-action) into a vector so that it can be fed to the NN. This method converts a given state-action pair into a vector format. Hint: The vector is of size m + t + d + m + m."""

       
    #     return state_encod


    ## Getting number of requests

    def requests(self, state):
        """Determining the number of requests basis the location.
        Use the table specified in the MDP and complete for rest of the locations"""
        """Location λ (of Poisson Distribution)
           Location A 2
           Location B 12
           Location C 4
           Location D 7
           Location E 8"""
        location = state[0]
        if location == 0:
            requests = np.random.poisson(2)
        elif location == 1:
            requests = np.random.poisson(12)
        elif location == 2:
            requests = np.random.poisson(4)
        elif location == 3:
            requests = np.random.poisson(7)
        elif location == 4:
            requests = np.random.poisson(8)
        #Cap the requests at 15
        if requests >15:
            requests =15
        possible_actions_index = random.sample(range(1, (m-1)*m +1), requests) # (0,0) is not considered as customer request
        actions = [self.action_space[i] for i in possible_actions_index]
       
        if (0, 0) not in actions:
            actions.append((0,0))
            possible_actions_index.append(len(self.action_space)-1) 
        
        return possible_actions_index,actions  


    def reward_func(self, state, action, Time_matrix):
        """Takes in state, action and Time-matrix and returns the reward"""
        #Current location, Pickup location, Drop location, Current time, Current day
        loc, pickup, drop, time, day = state[0], action[0], action[1], state[1], state[2]
        # Idle time, Time to pickup, Time to drop
        idletime, pickuptime, droptime = self.calculate_time(state, action, Time_matrix)
        #droptime * revenue - (droptime + pickuptime) * various-costs - idletime * various-costs
        reward= (R * droptime) - (C * (idletime + pickuptime + droptime))
        return reward, idletime+pickuptime+droptime

    def calculate_time(self,state, action, Time_matrix):
        #Current location, Pickup location, Drop location, Current time, Current day
        loc, pickup, drop, time, day = state[0], action[0], action[1], state[1], state[2]
        # Idle time, Time to pickup, Time to drop
        idletime, pickuptime, droptime = 0, 0, 0
        #The noride action just moves the time component by 1 hour
        if action == (0,0):
            idletime=1
        #If pickup is at current location, there is no pickuptime, but only time to drop    
        elif loc == pickup:    
            #Get the drop time
            droptime = Time_matrix[pickup][drop][time][day]
        #Pickup is at a different location than current.    
        else:  
            #Get the pickup time
            pickuptime = Time_matrix[loc][pickup][time][day]
            #Roll over time and day based on hours for pickup
            #Add delta time (in hours) and also add day(s) if the delta time spills over 24 hours
            time, day = int((time + pickuptime) % 24),int((day + math.floor((time + pickuptime)/24)) % 7)
            #Get drop time
            droptime = Time_matrix[pickup][drop][time][day]
        return idletime, pickuptime, droptime
   
           
    def next_state_func(self, state, action, Time_matrix, totaltime):
        """Takes state and action as input and returns next state"""
        #Current location, Pickup location, Drop location, Current time, Current day
        loc, pickup, drop, time, day = state[0], action[0], action[1], state[1], state[2]
        #Default next_loc to drop location
        #No ride = next location is current location
        nextloc = drop if action != (0,0) else loc
        #Rollover time and day
        nexttime, nextday = int((time + totaltime) % 24),int((day + math.floor((time + totaltime)/24)) % 7)
        next_state = [nextloc,nexttime,nextday]
        return next_state

    def step(self, state, action, Time_matrix):
        # Get the reward and totaltime
        reward, totaltime = self.reward_func(state, action, Time_matrix)
        # Get the next state
        nextstate = self.next_state_func(state, action, Time_matrix, totaltime)
        return reward, nextstate, totaltime    

    def reset(self):
        #Random initial state
        self.state_init = random.choice(self.state_space)
        return self.action_space, self.state_space, self.state_init